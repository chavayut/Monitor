﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebMonitorAndroid
{
    /// <summary>
    /// Summary description for WebAndroidMonitor
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebAndroidMonitor : System.Web.Services.WebService
    {
        OdbcConnection ODBConMonitorAndroid;
        OdbcCommand SqlStrMonitorAndroid;

        [WebMethod]
        [HttpGet]
        public string HelloWorld()
        {
            return "Hello World in method:  " + HttpContext.Current.Request.HttpMethod;
        }

        [WebMethod]
        [HttpGet]
        public Boolean Login(string eUser, string ePassword)
        {
            string q = "SELECT COUNT (*) as count from Agents where AgentID = '" + eUser + "' and Password= '" + ePassword + "'";
            Boolean userExist = false;
            ODBConMonitorAndroid = new OdbcConnection("DSN=CompositAppDB;UID=CompositUser;PWD=Composit1979;");
            SqlStrMonitorAndroid = new OdbcCommand(q, ODBConMonitorAndroid);
            SqlStrMonitorAndroid.Connection.Open();
            SqlStrMonitorAndroid.CommandType = CommandType.Text;
            OdbcDataReader reader = SqlStrMonitorAndroid.ExecuteReader();
            reader.Read();
            if (reader["count"].ToString().Trim() != "0")
                userExist = true;
            reader.Close();
            SqlStrMonitorAndroid.Connection.Close();
            return userExist;
        }


        [WebMethod]
        [HttpGet]
        public string GetMonitorData(string MonitorType, Boolean IsTable)
        {
            //int i = 0;
            string firstLineQuery = "select ColumName,ColumDescreption from AndroidMonitor where MonitorType='"+MonitorType+"'";
            string tableQuery = "SELECT MonitorTable from AndroidTypeMonitorTabels where MonitorType='" + MonitorType + "'";
            string monitorQuery = "select ";
            string tableMonitor = null;
            string tableColumnLine = null;
            string lines = null;
            string[] tableColumn;

            if(!IsTable)
                firstLineQuery = firstLineQuery+ " and ShowInGraph=1";

            ODBConMonitorAndroid = new OdbcConnection("DSN=CompositAppDB;UID=CompositUser;PWD=Composit1979;");
            SqlStrMonitorAndroid = new OdbcCommand(tableQuery, ODBConMonitorAndroid);
            SqlStrMonitorAndroid.Connection.Open();
            SqlStrMonitorAndroid.CommandType = CommandType.Text;

            //find monitor table
            OdbcDataReader reader = SqlStrMonitorAndroid.ExecuteReader();
            reader.Read();
            tableMonitor = reader["MonitorTable"].ToString().Trim();
            reader.Close();
           

            //build first line and monitor query
            SqlStrMonitorAndroid.CommandText = firstLineQuery;
            reader = SqlStrMonitorAndroid.ExecuteReader();
            reader.Read();
            while (reader.Read())
            {
                lines = lines + (reader["ColumDescreption"].ToString().Trim()) + "~";
                tableColumnLine = tableColumnLine + (reader["ColumName"].ToString().Trim()) + "~";
                monitorQuery = monitorQuery + (reader["ColumName"].ToString().Trim()) + ",";
            }
            reader.Close();

            //tableColumnLine = tableColumnLine.TrimEnd('~');
            monitorQuery = monitorQuery.TrimEnd(',');
            tableColumn = tableColumnLine.Split('~');
            lines = lines + "|";
            monitorQuery = monitorQuery + " from " + tableMonitor;
            
            //sellect all line 
            SqlStrMonitorAndroid.CommandText = monitorQuery;
            reader = SqlStrMonitorAndroid.ExecuteReader();
            reader.Read();
            while (reader.Read())
            {
                for (int i = 0; i < tableColumn.Length-1; i++)
                    lines = lines + (reader[tableColumn[i]].ToString().Trim()) + "~";
                //lines.TrimEnd('~');
                lines = lines + "|";
            }
            reader.Close();
            SqlStrMonitorAndroid.Connection.Close();
            ODBConMonitorAndroid.Close();
            return lines;
        }

    }

    class HttpGetAttribute : Attribute
    {
    }
}
